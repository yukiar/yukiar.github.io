CEFR-LS (lexical simplification based on CEFR levels) dataset
                        contact: Satoru Uchida (uchida@flc.kyushu-u.ac.jp)
                                 Shohei Takada (takada.syouhei@ist.osaka-u.ac.jp)
                                 Yuki Arase (arase@ist.osaka-u.ac.jp)

When you publish your study using this dataset, please add a reference to our LREC paper.

This dataset consists of following three files.
-open_dataset.tsv: lexical simplification dataset, presenting following items in TSV format
  --sentence
  --target
  --CEFR level of the target
  --1st candidate
  --CEFR level of the 1st candidate
  --annotation label of the 1st candidate (0 or 1, 0 represents this candidate does NOT replace the target, 1 means this candidate can replace the target.)
  --2nd candidate
  --...

-source_info.txt: shows detailed information of sources from which sentences are extracted
-source_index.txt: shows where each sentence has been extracted. Each number corresponds to the index of each source in source_info.txt 

Copyright:
This dataset is licensed under Creative Commons Attribution License (CC BY-NC-SA 4.0).

